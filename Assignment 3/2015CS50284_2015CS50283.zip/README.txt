*************************************************************************************************************************************************
frame/2
First element is name of frame with predicate "frame" with second elememt as list of slot name and value of it.

:- dymnamic frame/2.
This line of code represents which predicate is stored in dynamic database and "/2" tells its arity.

find(X,Y)
This function returns value of slot Y for frame X if exists in that frame or in frames above it using inheritence.

insert(X,Y)
It will insert a fact frame(X,Y) in dymnamic database.

delete(X)
It will delete frame(X) from database and its subtree.

update(X,Y,Z)
This will update value of Y in frame X to Z if Y exist in that frame.

*************************************************************************************************************************************************
:- dynamic frame/2.
:- style_check(-singleton).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Network of Frames		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
frame(hospital_frame,[country(default(india)),phone(default(9111234567)),address(nil)]).
frame(child_hospital,[ako(hospital_frame),age(range(0-12))]).
frame(heart_hospital,[ako(hospital_frame)]).
frame(lab,[a_part_of(hospital_frame)]).
frame(ward,[a_part_of(hospital_frame)]).
frame(doctor,[a_part_of(hospital_frame)]).
frame(pathology,[ako(lab),incharge(value(chandelar)),tests([ecg,blood_test,urine])]).
frame(x_ray_lab,[ako(lab),incharge(value(joey))]).
frame(orthopaedic_ward,[ako(ward)]).
frame(aiims,[inst(hospital),phone(value(9114146264)),address(value(central_delhi))]).
frame(kalawati,[inst(child_hospital),address(value("123_delhi")),phone(value(9175446464))]).
frame(escort,[inst(heart_hospital),phone(value(9115648446)),address(value("54_abc_delhi"))]).


% Inheritance Code and query
find(X,Y):-frame(X,Z),search(Y,Z),!.
find(X,Y):-frame(X,[inst(Z)|_]),find(Z,Y),!.
find(X,Y):-frame(X,[ako(Z)|_]),find(Z,Y),!.
find(X,Y):-frame(X,[a_part_of(Z)|_]),find(Z,Y).

find1(X,Y):-frame(X,Z),search(Y,Z).
find1(X,Y):-frame(X,[inst(Z)|_]),find1(Z,Y).
find1(X,Y):-frame(X,[ako(Z)|_]),find1(Z,Y).
find1(X,Y):-frame(X,[a_part_of(Z)|_]),find1(Z,Y).

% search function
search(X,[X|R]).
search(X,[Y|R]):-search(X,R).

%module to update
revers([],Z,Z).
revers([H|T],Z,Acc) :- revers(T,Z,[H|Acc]).

search1(X,[],Z,Z).
search1(X,[X|R],[],W):-search1(X,R,[],W).
search1(X,[X|R],Z,W):-search1(X,R,Z,W).
search1(X,[Y|R],[],W):-search1(X,R,[Y],W).
search1(X,[Y|R],Z,W):-search1(X,R,[Y|Z],W).

update(X,Y,Z1):- frame(X,V),find1(X,Z),compound_name_arguments(Z,Y,[K]),compound_name_arguments(B,Y,[Z1]), search1(Z,V,[],W),revers([B|W],A,[]),retract(frame(X,_)),asserta(frame(X,A)),!.

% Module to insert a frame
insert(X,Y) :- asserta(frame(X,Y)).

% Module to delete a frame
delet(X) :- frame(X,Y),retract(frame(X,Y)).
delet(X) :- frame(Z,[ako(X)|_]),delet(Z).
delet(X) :- frame(Z,[a_part_of(X)|_]),delet(Z).
delet(X) :- frame(Z,[inst(X)|_]),delet(Z).
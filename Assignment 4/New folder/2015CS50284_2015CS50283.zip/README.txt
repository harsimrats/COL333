Academics:-
	We have 4 Trapezoidal membership function for acads. Fail - (0,0,4,4), Average - (4,6,7,8), Good - (7,8,9,10), Excellent - (9,10,10,10).

Sports and Co-curricular:-
	4 Gaussian membership function. Poor - (4,0), Average - (5,5), Good - (4,10), Excellent - (10,18).

We gave acads slightly more importance than others but also considered that the person not focuses only on acads. Hence that person will have valid overall performance.
---------------------------------------------------------------------------------------Generating Magic cube-------------------------------------------------------------------------------------------------

This program uses algo for odd n.
The program initializes at a surface center with 1. It then starts Filling next numbers by moving in diagonal positions and on finding filled posn alters its path.
There are two levels at which the altering of path takes place. One on which the filled posn is reached by moving diagonally on which it changes the plane and the other in which filled posn is reached by changing planes on which it uses the previous plane and changes posn.
When the condition for 3rd level altering is reached the algo terminates.

______________________________________________________________________________________________________________________________________________________________________________________________________________

--------------------------------------------------------------------------------------Creating Exceptions Lists----------------------------------------------------------------------------------------------

The program first calculates all the tuples soln for the eqn  x + y + z =42.
Next it gets all the collinear points from the magic cube.
Using these two lists they then create a list which is both collinear and has sum 42. Subracting this list from the First two list gives us the two exception lists.

______________________________________________________________________________________________________________________________________________________________________________________________________________


---------------------------------------------------------------------------------------Next Optimal Position-------------------------------------------------------------------------------------------------

The code first tries to make a line in the cube if possible. it then checks if the opponent can create line in next move.If yes then it blocks it. If both are not possible then it plays at the centre position. If not then it tries to look into the future for possibly more chances of making lines.

_____________________________________________________________________________________________________________________________________________________________________________________________________________ 

